<template>
<!--
* Author: Maroš Berdis (xberdi01)
* Project: Fitstagram (ITU/IIS)
-->
    <span>
        <svg xmlns="http://www.w3.org/2000/svg"
            width="32"
            height="32"
            viewBox="0 0 25 25"
            class="fill-current">
        <path d="M6 1h13v1H6zM23 3H2v1h2v18.5A1.502 1.502 0 0 0 5.5 24h14a1.502 1.502 0 0 0 1.5-1.5V4h2zM9 20H8V7h1zm4 0h-1V7h1zm4 0h-1V7h1z"/></svg>
    </span>
</template>
