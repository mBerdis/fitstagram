<template>
<!--
* Author: Maroš Berdis (xberdi01)
* Project: Fitstagram (ITU/IIS)
-->
    <span>
        <svg xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 22.9 19.4"
            class="fill-current"
        >
            <path d="M22.903 2.828 20.075 0 6.641 13.435 3.102 9.09 0 11.616l6.338 7.779L22.903 2.828z"/>
        </svg>
    </span>
</template>
